# Sedjahe

Website statis untuk brand minuman herbal Sedjahe.

## Struktur

- `index.html` - landing page utama
- `produk.html` - katalog produk
- `tentang.html` - cerita brand
- `blog.html` dan `blog/` - artikel edukasi
- `assets/` - gambar, CSS hasil build, dan aset visual
- `robots.txt` dan `sitemap.xml` - file SEO teknis

## Deploy ke Vercel

Project ini bisa di-deploy sebagai static site.

1. Upload/push semua file ke repository GitHub.
2. Import repository di Vercel.
3. Framework preset: `Other`.
4. Build command: kosongkan jika hanya ingin deploy hasil static yang sudah ada.
5. Output directory: kosongkan atau gunakan root project.

## Tailwind CSS

File `assets/css/styles.css` sudah berisi hasil build Tailwind yang siap production.

Jika ingin build ulang:

```bash
npx tailwindcss -c tailwind.config.js -i ./src/input.css -o ./assets/css/styles.css --minify
```

## Catatan

Gambar produk sudah dikompres ke format `.jpg` agar halaman lebih ringan. File PNG besar produk lama tidak lagi dipakai.
